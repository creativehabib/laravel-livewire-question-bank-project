/*
Copyright (c) 2003-2025, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'mathjax', 'fi', {
	title: 'Matematiikkaa TeX:llä',
	button: 'Matematiikka',
	dialogInput: 'Kirjoita TeX:iä tähän',
	docUrl: 'http://en.wikibooks.org/wiki/LaTeX/Mathematics',
	docLabel: 'TeX dokumentaatio',
	loading: 'lataa...',
	pathName: 'matematiikka'
} );
